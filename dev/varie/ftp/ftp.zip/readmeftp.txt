REM Author: Jonathan Silber
REM Purpose: To automatically ftp the active (ascii) document in a text editor to a specified location on the server 
REM Comments: It was written for use with TextPad, but it should work with any editor that lets you call another application from inside itself

REM What this file does
REM 1. Creates a text file containing the ftp commands (ascii.txt)
REM 2. Calls the windows ftp utility and passes its -s parameter the path to the file containing the ftp commands

REM INSTRUCTIONS
REM 1. Open "ftpActiveDoc.bat" in TextPad, (Line 32) Replace the value that the variable "ftpascii" is set to with the full path name of ftp script file that this batch file will create on your PC
REM       For example, I have: set ftpascii=D:\Data\Technologies\FTP\ftpOpenFile\ftpascii.txt  
REM 2. (Line 33) Replace the value that the variable "destinationDir" is set to with the directory that you want to upload the active file to.
          For example, I have: set destinationDir=/opt/SilberSoft/html
REM 3. (Line 38) Replace "FTPServer" with your ftp server name or IP address
REM 4. (Line 39) Replace "username" with your username
REM 5. (Line 40) Replace "password" with your password
REM 6. Save & close ftpActiveDoc.bat
REM 7. Launch textpad.  From the Configure menu, select preferences
REM 8. Click on Tools in the left pane.  
REM 9. In the right pane click on the add button and from the drop-down list select Program
REM 10. In the Add Program dialog, select ftpActiveDoc.bat
REM 11. Click Open in the Add Program dialog.
REM 12. Click Ok in the preferences dialog
REM 13. Open a file in textpad
REM 14. To ftp a file: open it in textpad and from the tools menu select ftpActiveDoc

REM Fix:  Prepend REM to the following line: "For example, I have: set destinationDir=/opt/SilberSoft/html"
REM Bug:  Note that none of your paths can contain spaces.
REM Enhancement: The ftp commands that the script executes are now displayed in the Command Results window

