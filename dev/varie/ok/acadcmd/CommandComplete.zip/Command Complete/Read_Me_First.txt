Welcome to CommandComplete


CommandComplete is �Intellisense� for the AutoCAD command line, providing easy access to over 1400 commands and sysvars. 

Steps to load

1.      Extract all the files into the same folder on your computer.
2.	Start AutoCAD 2007/2008
3.	Run �APPLOAD� command
4a.	(For AutoCAD 2007 or AutoCAD 2008 32-bit) Load the AdskCommandComplete.arx file from the folder in which you unzipped it.
4b.     (For AutoCAD 2008 64-bit) Load the AdskCommandComplete_64.arx file from the folder in which you unzipped it.

To automatically load the application, you may add the file to Appload Startup Suite or create an acad.rx file and add the file name in it.


Description

- As the user types in the command prompt, a popup list appears displaying the list of commands and sysvars that match the input. 
 -  The auto-complete list is based on one or more of the following (selectable) search criteria:
        a. Start with user typed string. � Displays all matches where the command/sysvar begins with the text typed at the command line. For example, typing �LI� would list �LINE�, �LIGHT�, etc. (This base option is not selectable).
        b. Anywhere search. -- Displays all matches where the command/sysvar contains the typed text anywhere in its name. (For example, typing �LI� would list �LINE�, �PUBLISH�, �ALIGN�, etc.   
        c. Keyword search � Additional keywords can be defined in commandcomplete.xml for every command. This option would display all commands/sysvars where the typed text was contained within one of your keywords. The default commandcomplete.xml file does not define any keywords. However, you can include keywords by editing the XML file.  Please refer Case 2 example in the customization section of this file.
- These search criteria can be switched on/off using CommandComplete options menu that is available through the AutoCAD default context menu. Right click on the drawing to display AutoCAD context menu -> CommandComplete Options.
- Tool tips will appear for every command, containing a short description of that command.
- Tool tips will show the current value of sysvars.
-  ObjectARX and .NET defined custom commands  are also displayed in the auto-complete list. The utility automatically detects new commands added when an ObjectARX/.NET application is loaded. 
- CommandComplete alters the standard AutoCAD keyboard behavior in a minimal way. You can use the UP and DOWN arrow keys to scroll the list and TAB or double-click on the list to use the selected command. CTRL + SPACE can be used to display the complete list of commands.


CommandComplete Options Menu

The CommandComplete options menu is added to the AutoCAD default context menu.  Right click on the drawing to display the AutoCAD context menu and click on the CommandComplete Options to display the options available:
  Enable CComplete � Turns  the CommandComplete utility on or off.
  Enable Tooltips � Turns CommandComplete tooltips on or off
  Commands � Include or exclude commands from the CommandComplete list
  System Variables - Include or exclude system variables from the CommandComplete list
(If neither or both of these two options are enabled, then both the commands and sysvars will be listed in the CommandComplete list).
  Search Anywhere - Enable/Disable Anywhere search option 
  Search Keywords � Enable/Disable Keyword search option


Customization

The CommandComplete utility uses the commandcomplete.xml file to search for Native AutoCAD commands & sysvars. The CommandComplete list displays only the English commands as the XML file contains the English names. However, the file can be edited to search based on the local names. The format of this XML file is. 
<CommandComplete>
<CommandCollection>
---------------------------------------------
<Command id="251" displayname="-PLOT" commandstring="-PLOT" tooltip="Plots a drawing to a plotter printer or file from command line" keywords="" sysvar="0" />
---------------------------------------------
</CommandCollection>
</CommandComplete>

Where -
id � Unique identification number of the command in the list. 
displayname � Name of the command as displayed in the auto-complete list
commandstring � Search string used to search for the command
tooltip � Tooltip to be displayed for the command (The value of sysvar is also displayed if it is a sysvar) 
keywords � Additional string that can optionally be included in the CommandComplete search
sysvar � Identifier to know if it is a system variable. Set to �1� for a sysvar, otherwise to �0�
Additionally, commands added by external ARX/.NET modules are always searched based on their global names
Examples of customizing CommandComplete.xml:
Case 1: Modify �-PLOT� command so that it is displayed as �TEST� in the popup list
1.	Open commandcomplete.xml file in notepad or any other text editor.
2.	Find string - �-PLOT�.  
3.	The following XML Node of PLOT should be modified: 
<Command id="251" displayname="-PLOT" commandstring="-PLOT" tooltip=" Plots a drawing to a plotter printer or file from command line" keywords="" sysvar="1"/>
4.	<Command id="251" displayname="TEST" commandstring="-PLOT" tooltip="Alias for PLOT command" keywords="" sysvar="1"/>
5.	Save the file.
Case 2: Add keyword a�HATCH� for system variable HPANG (Specifies the hatch pattern angle)
1.	Open commandcomplete.xml file in notepad or any other text editor.
2.	Find string - �HPANG�.  
3.	The following XML Node of HPANG should be modified from
     <Command id="1120" displayname="HPANG" commandstring="HPANG" tooltip="Specifies the hatch pattern angle." keywords="" sysvar="1"/>
to 
     <Command id="1120" displayname="HPANG" commandstring="HPANG" tooltip="Specifies the hatch pattern angle." keywords="HATCH" sysvar="1"/>
4.	Save the file.


_______________________________________

Autodesk Labs Terms of Use
The terms set forth below (the �Agreement�) govern your use of the Autodesk Labs website (the �Site�). By using or visiting the Site, you expressly agree to be bound by this Agreement and to follow all terms and applicable laws and regulations governing the Site. Further, your use of this Site is subject to those additional terms and conditions provided by Autodesk and, subject to Autodesk�s sole discretion, applicable to certain information, pre-release products, and software (collectively, �Content�) available through this Site. Such additional terms and conditions include, but are not limited to, disclaimers, license agreements and supplementary user agreements (collectively, "Additional Terms"). The Additional Terms are hereby incorporated by reference into these Terms (if there is any conflict between the Additional Terms and these Terms, the former shall prevail). If you do not agree with this Agreement, your sole recourse is not to use the Site.
The services and content provided as part of the Site are experimental in nature. They have not been tested in any manner, and Autodesk does not represent that they are reliable, accurate, complete, or otherwise valid. Accordingly, the site and any content is provided �as is� with no warranty of any kind and you use the service at your own risk. Autodesk expressly disclaims any warranty, express or implied, regarding the site or its content, including any implied warranty of merchantability, fitness for a particular purpose or non-infringement. Some states do not allow the exclusion of warranty, so the above exclusions may not apply to you.
1.	Qualified User. You may use the Autodesk Labs site only if you are a registered user of AutoCAD or other Autodesk software (collectively �Software�). This Agreement does not modify or alter the terms of the End User License Agreement delivered with the Software.
2.	Use of the Site. The Content on this Site is the property of Autodesk and/or its suppliers and is protected by U.S. and international intellectual property laws. Accordingly, you agree that you will not copy, reproduce, alter, modify, create derivative works of, or publicly display or perform any Content from the Site. You also agree that you will not use any automated device or manual process to monitor or copy any Content from the Site. Any software that is made available to download by or through this Site is governed by the terms of the license agreement, if any, which accompanies or is included with the software. The site may not be used for commercial purposes.
3.	Feedback. In using this Site, you may provide certain comments, suggestions, data, or other information to Autodesk (collectively �Feedback�). Autodesk shall have the right to retain and use any such Feedback in current or future products or services, without additional compensation to you. To the extent such Feedback is protectable under intellectual property laws, you agree to cooperate with Autodesk as needed to obtain such protection as Autodesk may desire and you agree to assign your rights to such Feedback to Autodesk.
4.	Privacy. Autodesk may share aggregate (not personally identifiable) information with its business partners or other third parties. Autodesk will not, however, knowingly disclose personally identifiable information to third parties unless required to do so in order to comply with any valid legal process, such as a search warrant, subpoena, statute, court order, or if necessary or appropriate, to address an unlawful or harmful activity.
5.	Limitation of Liability. UNDER NO CIRCUMSTANCES WILL AUTODESK BE LIABLE TO YOU FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL OR EXEMPLARY DAMAGES ARISING OUT OF OR IN CONNECTION WITH USE OF THE SITE, WHETHER OR NOT AUTODESK HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. UNDER NO CIRCUMSTANCES SHALL AUTODESK BE LIABLE TO YOU FOR ANY AMOUNT. Some states do not allow the exclusion of limitation of incidental or consequential damages, so the above limitation and exclusions may not apply to you. 
6.	Release and Waiver. To the maximum extent permitted by applicable law, you hereby release and waive all claims against Autodesk and its employees and agents from any and all liability for claims, damages (actual and consequential), costs and expenses (including litigations costs and attorneys� fees) of every kind and nature, arising out of or in any way connected with use of the Site. If you are a California resident, you waive your rights under California Civil Code � 1542, which states �A general release does not extend to claims which the creditor does not know or suspect to exist in his favor at the time of executing the release, which if known to him must have materially affected his settlement with the debtor.� Residents of other states and nations similarly waive their rights under applicable and/or analogous laws, statutes, or regulations.
7.	Modification of Terms. Autodesk shall have the right to modify the terms of this Agreement at any time, which modification shall be effective immediately upon posting to the Site.
8.	Use of the Site. Violation of Terms. In addition to any legal remedies that Autodesk may have for your violation of the terms of this Agreement, Autodesk shall also have the right in its sole discretion to suspend or terminate your access to the Site.
9.	Indemnification. You agree to hold harmless and indemnify Autodesk and its employees, agents, and representatives from and against any third party claim arising from or in any way related to your use of the Site, including any liability or expense arising from all claims, losses, damages (actual and consequential), suites, judgments, litigations costs and attorneys� fees, or every kind and nature. In such a case, Autodesk will provide you with written notice of such claim, suit, or action.
10.	Assignment. You may not assign this Agreement or assign any rights or delegate any obligations hereunder, in whole or in part, whether voluntarily or by operation of law, without Autodesk�s prior written consent. Any such purported assignment or delegation by you without Autodesk�s prior written consent will be null and void and of no force and effect, unless otherwise expressly consented to by Autodesk in its sole discretion.
11.	Relationship of the Parties. Notwithstanding any provision of this Agreement, each party shall be and act as an independent contractor and not as partner, joint venturer, agent, employee or employer of the other and shall not bind nor attempt to bind the other to any contract.
12.	General. If any provision of this Agreement is held to be invalid or unenforceable, such provision shall be deemed superseded by a valid enforceable provision that most closely matches the intent of the original provision and the remaining provisions shall be enforced. Autodesk�s failure to act with respect to a breach by you or others does not waive Autodesk�s right to act with respect to subsequent or similar breaches. The failure of Autodesk to exercise or enforce any right or provision of these terms and conditions shall not constitute a waiver of such right or provision. The section headings and subheadings contained in this Agreement are included for convenience only, and shall not limit or otherwise affect the terms of this Agreement. This Agreement shall be governed by the laws of the State of California (except that body of law controlling conflict of laws) and the United States of America. You submit to and waive any objection against the exclusive personal jurisdiction of the United States District Court for the Northern District of California, San Francisco, and the Superior Court of the State of California, County of Marin. This Agreement constitutes the entire agreement between Autodesk and you with respect to the Site and may not be modified except by a written instrument executed by you and an authorized representative of Autodesk.


